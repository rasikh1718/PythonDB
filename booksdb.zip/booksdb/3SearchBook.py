
from logging import exception
import pymysql

con=pymysql.connect(host='bsdd0rpqqz9qvrkzcnhr-mysql.services.clever-cloud.com',user='uyu0gdfgiasqmkeq',passwd='12RKXpmWmMEOS2cDWJA5',database='bsdd0rpqqz9qvrkzcnhr')
bookcode=int(input('Enter bookcode : '))

curs=con.cursor()
curs.execute("select * from books where bookcode=%d"%(bookcode))
data=curs.fetchone()
try:
    print(data)
    
except exception as e:
    print('not found',e)
    
con.close()