
from linecache import cache
from unicodedata import category
import pymysql

con=pymysql.connect(host='bsdd0rpqqz9qvrkzcnhr-mysql.services.clever-cloud.com',user='uyu0gdfgiasqmkeq',passwd='12RKXpmWmMEOS2cDWJA5',database='bsdd0rpqqz9qvrkzcnhr')
typ=input('enter category of book :')

curs=con.cursor()

curs.execute("select * from books where category='%s'"%(typ))
data=curs.fetchall()
# print(data)
for rec in data:
    print(rec)


con.close()