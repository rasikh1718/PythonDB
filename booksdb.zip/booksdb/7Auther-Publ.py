import pymysql

con=pymysql.connect(host='bsdd0rpqqz9qvrkzcnhr-mysql.services.clever-cloud.com',user='uyu0gdfgiasqmkeq',passwd='12RKXpmWmMEOS2cDWJA5',database='bsdd0rpqqz9qvrkzcnhr')
curs=con.cursor()
author=input('Enter auther name :')
pub=input('enter publication : ')
curs.execute("select * from books where author='%s' or publication='%s'"%(author,pub))
data=curs.fetchall()
# print(data)
for rec in data:
    print(rec)

con.close()    