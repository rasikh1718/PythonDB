import pymysql

con=pymysql.connect(host='bsdd0rpqqz9qvrkzcnhr-mysql.services.clever-cloud.com',user='uyu0gdfgiasqmkeq',passwd='12RKXpmWmMEOS2cDWJA5',database='bsdd0rpqqz9qvrkzcnhr')
curs=con.cursor()

try:
    bookcode=int(input('Enter book code that want to delete :'))
    curs.execute("select * from books where bookcode=%d"%(bookcode))
    data=curs.fetchone()
    if data:
        print('Do you want to Delete ? type yes or no ')
        typ=input('yes or no :')
        if typ.upper()==('YES'):
            curs.execute('delete from books where bookcode=%d'%(bookcode))
            con.commit()
            print('Book succesfully deleted')
        elif typ.upper()==('NO'):
            print('book is available')


    else:
        print('book does not exist')        

except:
    print('invalid bookcode try again')    