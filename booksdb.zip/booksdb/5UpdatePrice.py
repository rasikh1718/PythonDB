from distutils.util import execute
import pymysql

con=pymysql.connect(host='bsdd0rpqqz9qvrkzcnhr-mysql.services.clever-cloud.com',user='uyu0gdfgiasqmkeq',passwd='12RKXpmWmMEOS2cDWJA5',database='bsdd0rpqqz9qvrkzcnhr')
curs=con.cursor()

bookcode=int(input('Enter the bookcode :'))
curs.execute("select * from books where bookcode=%d"%(bookcode))

data=curs.fetchone()

if data:
    price=int(input('Enter new price of book: '))
    print('update books set price=%d where bookcode=%d'%(price,bookcode))
    curs.execute('update books set price=%d where bookcode=%d'%(price,bookcode))
    con.commit()
    print('Book new Price update suucessfully')
else:
    print('book does not exist..') 

con.close()