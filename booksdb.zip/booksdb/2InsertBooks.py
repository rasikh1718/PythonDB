
from logging import exception
import pymysql

bookcode=int(input('Enter Bookcode number : '))
booknm=input('Enter Book name  : ')
category=input('Enter type of book : ')
auther=input('Enter author name : ')
publication=input('Enter publication : ')
edition=input('Enter edition : ')
price=float(input('Enter Price : '))


# con=pymysql.connect(host='bsdd0rpqqz9qvrkzcnhr-mysql.services.clever-cloud.com',user='uyu0gdfgiasqmkeq',password='12RKXpmWmMEOS2cDWJA5',database='bsdd0rpqqz9qvrkzcnhr')

con=pymysql.connect(host='bsdd0rpqqz9qvrkzcnhr-mysql.services.clever-cloud.com',user='uyu0gdfgiasqmkeq',passwd='12RKXpmWmMEOS2cDWJA5',database='bsdd0rpqqz9qvrkzcnhr')
curs=con.cursor()

print("insert into books values (%d,'%s','%s','%s,'%s','%s',%.2f)" %(bookcode,booknm,category,auther,publication,edition,price))


try:
    curs.execute("insert into books values (%d,'%s','%s','%s','%s','%s',%.2f)" %(bookcode,booknm,category,auther,publication,edition,price))
    con.commit()
    print('Book added succesfully')
except exception as e:
    print('Data insert fail',e)   

con.close()



