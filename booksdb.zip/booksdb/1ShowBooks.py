import pymysql

con=pymysql.connect(host='bsdd0rpqqz9qvrkzcnhr-mysql.services.clever-cloud.com',user='uyu0gdfgiasqmkeq',passwd='12RKXpmWmMEOS2cDWJA5',database='bsdd0rpqqz9qvrkzcnhr')
curs=con.cursor()
curs.execute("select * from books")
# data=curs.fetchall()
# print(data)rec=curs.fetchone()
rec=curs.fetchone()
while rec:
    print(rec)
    rec=curs.fetchone()

con.close()