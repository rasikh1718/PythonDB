
import pymysql

con=pymysql.connect(host='bsdd0rpqqz9qvrkzcnhr-mysql.services.clever-cloud.com',user='uyu0gdfgiasqmkeq',passwd='12RKXpmWmMEOS2cDWJA5',database='bsdd0rpqqz9qvrkzcnhr')
curs=con.cursor()
bookcode=int(input('Enter the bookcode :'))

curs.execute("select * from books where bookcode=%d"%(bookcode))
data=curs.fetchone()
if data:
    #   print(data)
    review=input('Enter your review on this book here:')
    print("update books  review='%s' where bookcode=%d"%(review,bookcode))
    curs.execute("update books set review='%s' where bookcode=%d"%(review,bookcode))
    con.commit()
    print('Review updated')

else:
    print('invalid bookcode ')    
con.close()
